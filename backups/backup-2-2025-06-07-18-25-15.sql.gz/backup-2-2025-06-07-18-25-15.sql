-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: Inventory
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance_adjustments`
--

DROP TABLE IF EXISTS `balance_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_adjustments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `offset_amount` double DEFAULT NULL,
  `reason` longtext COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_balance_adjustments_user_id` (`user_id`),
  KEY `idx_balance_adjustments_created_by` (`created_by`),
  CONSTRAINT `fk_balance_adjustments_created_by_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_balance_adjustments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_adjustments`
--

LOCK TABLES `balance_adjustments` WRITE;
/*!40000 ALTER TABLE `balance_adjustments` DISABLE KEYS */;
INSERT INTO `balance_adjustments` VALUES (16,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 07:47:24 ب.ظ'),(22,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:11:10 ب.ظ'),(23,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:16:33 ب.ظ'),(24,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:17:47 ب.ظ'),(25,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:20:15 ب.ظ'),(26,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:21:24 ب.ظ'),(27,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:22:13 ب.ظ'),(28,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:32:32 ب.ظ'),(29,1,0,'قیمت اصلاحی',1,'1404/03/01 چهارشنبه 08:37:48 ب.ظ'),(31,2,566250,'بدهی مانده',1,'1404/03/01 چهارشنبه 08:39:07 ب.ظ'),(32,2,-132500,'پایان',1,'1404/03/01 چهارشنبه 08:39:28 ب.ظ'),(33,2,-1000000,'سی',1,'1404/03/01 چهارشنبه 08:39:42 ب.ظ'),(35,2,1000000,'q',1,'1404/03/01 چهارشنبه 09:25:05 ب.ظ'),(36,1,0,'قیمت اصلاحی',1,'1404/03/06 دوشنبه 03:43:18 ب.ظ'),(37,1,0,'قیمت اصلاحی',1,'1404/03/06 دوشنبه 06:49:40 ب.ظ'),(38,1,0,'قیمت اصلاحی',1,'1404/03/06 دوشنبه 06:50:40 ب.ظ'),(39,1,0,'قیمت اصلاحی',1,'1404/03/06 دوشنبه 07:06:10 ب.ظ'),(40,1,0,'قیمت اصلاحی',1,'1404/03/18 شنبه 06:25:15 ب.ظ');
/*!40000 ALTER TABLE `balance_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_products`
--

DROP TABLE IF EXISTS `export_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `export_id` bigint unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rolle_price` double DEFAULT NULL,
  `meter_price` double DEFAULT NULL,
  `weight_price` double DEFAULT NULL,
  `count_price` double DEFAULT NULL,
  `barrel_price` double DEFAULT NULL,
  `roll` bigint DEFAULT NULL,
  `meter` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `count` bigint DEFAULT NULL,
  `barrel` bigint DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `inventory_id` bigint unsigned DEFAULT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `measurement_system` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_export_products_export_id` (`export_id`),
  KEY `idx_export_products_inventory_id` (`inventory_id`),
  KEY `idx_export_products_product_id` (`product_id`),
  CONSTRAINT `fk_export_products_inventory` FOREIGN KEY (`inventory_id`) REFERENCES `inventories` (`id`),
  CONSTRAINT `fk_export_products_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_exports_export_products` FOREIGN KEY (`export_id`) REFERENCES `exports` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_products`
--

LOCK TABLES `export_products` WRITE;
/*!40000 ALTER TABLE `export_products` DISABLE KEYS */;
INSERT INTO `export_products` VALUES (9,2,' ایزوگام شرق صادراتی',99250,0,0,0,0,3,0,0,0,0,297750,2,1,''),(10,3,' ایزوگام شرق صادراتی',99250,0,0,0,0,5,0,0,0,0,496250,1,1,''),(11,3,'ایزوگام غرب شرق مخصوص',87500,0,0,0,0,5,0,0,0,0,437500,1,2,''),(12,3,'ایزوگام شمال شرق بدون فویل',110000,0,0,0,0,10,0,0,0,0,1100000,1,3,''),(13,3,'ایزوگام سپید گام صادراتی',95000,0,0,0,0,100,0,0,0,0,9500000,1,4,''),(14,3,'ایزوگام سپیدگام صادراتی بدون فویل',105000,0,0,0,0,10,0,0,0,0,1050000,1,5,''),(15,3,'ایزوگام اصلاحی درجه ۲',0,108000,0,0,0,0,10.5,0,0,0,1134000,1,6,''),(16,3,'ایزوگام شرق طرح دار',95000,0,0,0,0,75,0,0,0,0,7125000,1,7,''),(17,3,'بشکه قیر',0,0,0,0,108000,0,0,0,0,75,8100000,1,8,''),(18,4,' ایزوگام شرق صادراتی',99250,0,0,0,0,5,0,0,0,0,496250,1,1,''),(19,4,'ایزوگام غرب شرق مخصوص',87500,0,0,0,0,5,0,0,0,0,437500,1,2,''),(20,4,'ایزوگام شمال شرق بدون فویل',110000,0,0,0,0,10,0,0,0,0,1100000,1,3,''),(21,4,'ایزوگام سپید گام صادراتی',95000,0,0,0,0,100,0,0,0,0,9500000,1,4,''),(22,4,'ایزوگام سپیدگام صادراتی بدون فویل',105000,0,0,0,0,10,0,0,0,0,1050000,1,5,''),(23,4,'ایزوگام اصلاحی درجه ۲',0,108000,0,0,0,0,10.5,0,0,0,1134000,1,6,''),(24,4,'ایزوگام شرق طرح دار',95000,0,0,0,0,75,0,0,0,0,7125000,1,7,''),(25,4,'بشکه قیر',0,0,0,0,108000,0,0,0,0,75,8100000,1,8,''),(26,5,' ایزوگام شرق صادراتی',99250,0,0,0,0,5,0,0,0,0,496250,1,1,''),(27,5,'ایزوگام غرب شرق مخصوص',87500,0,0,0,0,5,0,0,0,0,437500,1,2,''),(28,5,'ایزوگام شمال شرق بدون فویل',110000,0,0,0,0,10,0,0,0,0,1100000,1,3,''),(29,5,'ایزوگام سپید گام صادراتی',95000,0,0,0,0,100,0,0,0,0,9500000,1,4,''),(30,5,'ایزوگام سپیدگام صادراتی بدون فویل',105000,0,0,0,0,10,0,0,0,0,1050000,1,5,''),(31,5,'ایزوگام اصلاحی درجه ۲',0,108000,0,0,0,0,10.5,0,0,0,1134000,1,6,''),(32,5,'ایزوگام شرق طرح دار',95000,0,0,0,0,75,0,0,0,0,7125000,1,7,''),(33,5,'بشکه قیر',0,0,0,0,108000,0,0,0,0,75,8100000,1,8,''),(34,6,' ایزوگام شرق صادراتی',99250,0,0,0,0,5,0,0,0,0,496250,1,1,''),(35,6,'ایزوگام غرب شرق مخصوص',87500,0,0,0,0,5,0,0,0,0,437500,1,2,''),(36,6,'ایزوگام شمال شرق بدون فویل',110000,0,0,0,0,10,0,0,0,0,1100000,1,3,''),(37,6,'ایزوگام سپید گام صادراتی',95000,0,0,0,0,100,0,0,0,0,9500000,1,4,''),(38,6,'ایزوگام سپیدگام صادراتی بدون فویل',105000,0,0,0,0,10,0,0,0,0,1050000,1,5,''),(39,6,'ایزوگام اصلاحی درجه ۲',0,108000,0,0,0,0,10.5,0,0,0,1134000,1,6,''),(40,6,'ایزوگام شرق طرح دار',95000,0,0,0,0,75,0,0,0,0,7125000,1,7,''),(41,6,'بشکه قیر',0,0,0,0,108000,0,0,0,0,75,8100000,1,8,'');
/*!40000 ALTER TABLE `export_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exports`
--

DROP TABLE IF EXISTS `exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` longtext COLLATE utf8mb4_unicode_ci,
  `phonenumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `creator_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `tax` bigint DEFAULT NULL,
  `describe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` longtext COLLATE utf8mb4_unicode_ci,
  `draft` tinyint(1) DEFAULT NULL,
  `inventory_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_exports_user_id` (`user_id`),
  KEY `idx_exports_inventory_id` (`inventory_id`),
  CONSTRAINT `fk_exports_inventory` FOREIGN KEY (`inventory_id`) REFERENCES `inventories` (`id`),
  CONSTRAINT `fk_exports_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exports`
--

LOCK TABLES `exports` WRITE;
/*!40000 ALTER TABLE `exports` DISABLE KEYS */;
INSERT INTO `exports` VALUES (2,'حسین عباسی','M09358','09125174858',2,'hossein Soltanian','هزار راه نرفته',553750,256000,'یک توضیح خاص','1404/03/01 چهارشنبه 03:03:10 ب.ظ',1,2),(3,'حسین سلطانیان','9283422','09125174854',1,'hossein Soltanian','کرج -کرج=-ایران -سیسی',10000000,10,'','1404/03/06 دوشنبه 06:49:40 ب.ظ',0,1),(4,'حسین سلطانیان','9283422','09125174854',1,'hossein Soltanian','کرج -کرج=-ایران -سیسی',10000000,10,'','1404/03/06 دوشنبه 06:50:40 ب.ظ',0,1),(5,'حسین سلطانیان','9283422','09125174854',1,'hossein Soltanian','کرج -کرج=-ایران -سیسی',10000000,10,'','1404/03/06 دوشنبه 07:06:10 ب.ظ',0,1),(6,'حسین سلطانیان','9283422','09125174854',1,'hossein Soltanian','کرج -کرج=-ایران -سیسی',10000000,10,'','1404/03/18 شنبه 06:25:15 ب.ظ',0,1);
/*!40000 ALTER TABLE `exports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventories`
--

DROP TABLE IF EXISTS `inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventories`
--

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
INSERT INTO `inventories` VALUES (1,'انبار اشتهارد'),(2,'انبار زنجان');
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` longtext COLLATE utf8mb4_unicode_ci,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `describe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` longtext COLLATE utf8mb4_unicode_ci,
  `export_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `inventory_id` bigint unsigned DEFAULT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_payments_export_id` (`export_id`),
  KEY `idx_payments_user_id` (`user_id`),
  KEY `idx_payments_inventory_id` (`inventory_id`),
  CONSTRAINT `fk_exports_payments` FOREIGN KEY (`export_id`) REFERENCES `exports` (`id`),
  CONSTRAINT `fk_payments_inventory` FOREIGN KEY (`inventory_id`) REFERENCES `inventories` (`id`),
  CONSTRAINT `fk_payments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,'نقدی','PMT-650421','نقدی',120000,'','۱۴۰۴/۰۳/۰۱',2,2,2,'collected'),(2,'چک','3453453','ملی',12000000,'','۱۴۰۴/۰۳/۰۱',2,2,2,'pending'),(3,'مستقیم','9283422','ملی',9000,'کرج -کرج=-ایران -سیسی','1404/03/06 دوشنبه 06:49:40 ب.ظ',3,1,1,'collected'),(4,'مستقیم','9283422','ملی',9000,'کرج -کرج=-ایران -سیسی','1404/03/06 دوشنبه 06:50:40 ب.ظ',4,1,1,'collected'),(5,'مستقیم','9283422','ملی',9000,'کرج -کرج=-ایران -سیسی','1404/03/06 دوشنبه 07:06:10 ب.ظ',5,1,1,'collected'),(6,'مستقیم','9283422','ملی',9000,'کرج -کرج=-ایران -سیسی','1404/03/18 شنبه 06:25:15 ب.ظ',6,1,1,'collected');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rolle_price` double DEFAULT NULL,
  `meter_price` double DEFAULT NULL,
  `weight_price` double DEFAULT NULL,
  `count_price` double DEFAULT NULL,
  `barrel_price` double DEFAULT NULL,
  `roll` bigint DEFAULT NULL,
  `meter` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `count` bigint DEFAULT NULL,
  `barrel` bigint DEFAULT NULL,
  `inventory_id` bigint unsigned DEFAULT NULL,
  `measurement_system` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_products_inventory_id` (`inventory_id`),
  CONSTRAINT `fk_products_inventory` FOREIGN KEY (`inventory_id`) REFERENCES `inventories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,' ایزوگام شرق صادراتی',99250,0,0,0,0,97,0,0,0,0,2,'roll'),(2,'ایزوگام غرب شرق مخصوص',92500,0,0,0,0,80,0,0,0,0,2,'roll'),(3,'ایزوگام شمال شرق بدون فویل',110000,0,0,0,0,115000,0,0,0,0,2,'roll'),(4,'ایزوگام سپید گام صادراتی',95000,0,0,0,0,120,0,0,0,0,2,'roll'),(5,'ایزوگام سپیدگام صادراتی بدون فویل',87500,0,0,0,0,80,0,0,0,0,2,'roll'),(6,'ایزوگام اصلاحی درجه ۲',0,108000,0,0,0,0,50,0,0,0,2,'meter'),(7,'ایزوگام شرق طرح دار',95000,0,0,0,0,120,0,0,0,0,2,'roll'),(8,'بشکه قیر',0,0,0,0,108000,0,0,0,0,75,2,'barrel');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_users_phonenumber` (`phonenumber`),
  KEY `unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'hossein Soltanian','hosseinbidar7@gmail.com','$2a$14$xHWkBBB6Fg20FLDwrPR9le8mAN72x7ZUuUB.wKq9ycgB3v3PTAdTC','09125174854','','Admin'),(2,'مجید رضایی','as@a.a','$2a$14$9HYA0PXNqR/uOQ1zrEVG2.3cO7lxNgiM3Y2oULsM9SWmNdG9Oe6Lm','09125174858','','guest');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-07 18:25:15
